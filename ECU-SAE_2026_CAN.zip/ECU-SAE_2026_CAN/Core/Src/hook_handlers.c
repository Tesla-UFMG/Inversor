/*
 * hook_handlers.c
 *
 *  Created on: Feb 1, 2021
 *      Author: renanmoreira
 */
#include "hook_handlers.h"

#include "cmsis_os.h"
#include "stm32h7xx.h"
#include "util/util.h"

// void vApplicationMallocFailedHook(void) {
//	memory allocation error
// }

void brkpt() {
    ;
}

void vAssertCalled(const char* pcFile, unsigned long ulLine) {
    UNUSED(pcFile);
    UNUSED(ulLine);

    volatile unsigned long ul = 0;

    taskENTER_CRITICAL();
    {
        while (ul == 0) {
            portNOP();
        }
    }
    taskEXIT_CRITICAL();
}
