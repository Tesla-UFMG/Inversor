/*
 * global_definitions.h
 *
 *  Created on: 11 de mai de 2020
 *      Author: renanmoreira
 */

#ifndef INC_GLOBAL_DEFINITIONS_H_
#define INC_GLOBAL_DEFINITIONS_H_

#include "stdbool.h"
#include "stdint.h"

#define DEBUG_ECU 1

#define WHEEL_ENCODERS_AVAILABLE 4
//sensor velocity pins
typedef enum { FRONT_RIGHT = 0, FRONT_LEFT, REAR_RIGHT, REAR_LEFT } speed_pin_e;
//colors of ECU LED
typedef enum { PRETO = 0, VERMELHO, VERDE, AZUL, AMARELO, ROXO, CIANO, BRANCO } cores_t;

typedef enum { ERRO = 0, ENDURO, ACELERACAO, SKIDPAD, AUTOX } race_mode_t;

typedef struct        // mode struct
{
    int tor_max;      // max torque (from 0 to 4000)
    int vel_max;      // maximum velocity (from 0 to 9000)
    bool freio_regen; // regenerative braking (1 for activated, 0 for disabled)
    bool dif_elt;     // electronic differential (1 active, 0 disabled)

    // bool arranc_control;

    bool traction_control; // traction control (1 ativo, 0 desat)
    bool bat_safe; // reducing battery consumption when it is in critical levels (1 active, 0
                   // disabled)
    int torq_gain; // torque gain, recommended that should be proportional to the maximum torque(
                   // de 0 a 40)
    race_mode_t mode; // 1 enduro, 2 aceleration, 3 skidpad, 4 autox
    cores_t cor;
} modos;

#define R_MOTOR 0
#define L_MOTOR 1

// CONTROLE.c

typedef struct {
    uint8_t parameter_control;
    uint16_t ref_torque_neg[2];
    uint16_t ref_veloc[2];
    bool regen_active;
} vehicle_state_parameters_t;

typedef struct {
    uint16_t ref_torque[2];
    bool disable;
} ref_torque_t;

typedef enum estado_veiculo {
    S_DISABLE_E    = 0,
    S_BRAKE_E      = 1,
    S_ACCELERATE_E = 2,
    S_NEUTER_E     = 3
} vehicle_state_e;

//----------

typedef struct {
    uint8_t parameters;
    uint32_t torque_ref[2];
    uint32_t neg_torque_ref[2];
    uint32_t speed_ref[2];
} torque_message_t;

// DATALOG

typedef struct {
    uint16_t id;
    uint16_t data;
} datalog_message_t;

//-----------

#define ADC_LINES 6

typedef enum {
    APPS1_E          = 0,
    APPS2_E          = 5,
    STEERING_WHEEL_E = 1,
    BRAKE_E          = 3,
    ADC_E1_E         = 4,
    ADC_E2_E         = 2
} ADC_DMA_position_e;

#define APPS_PLAUSIBILITY_PERCENTAGE_TOLERANCE 10

// Thread Flags (Flags that are not in the ECU_control_flags and are only for
// communication between two tasks)
#define RTD_BTN_PRESSED_THREAD_FLAG                     (1 << 0)
#define MODE_BTN_PRESSED_THREAD_FLAG                    (1 << 1)
#define DYNAMIC_CONTROLS_CHOICE_BTN_PRESSED_THREAD_FLAG (1 << 2)
#define ODOMETER_SAVE_THREAD_FLAG                       (1 << 3)

// ** ECU_control_flags **
// Below are flags that are part of the ECU_control_flags, a 32 bit variable, they can be
// used in all tasks and for datalogging. They are divided in four groups, general flags
// (0 to 9), warning flags (10 to 15), soft errors flags (16 to 18) and hard errors flags
// (19 to 32).

// General flags
#define RTD_FLAG                   (1 << 0)
#define GENERAL_BUS_OFF_ERROR_FLAG (1 << 1)
#define INVERTER_READY_FLAG        (1 << 2)
#define DYNAMIC_CONTROL_FLAG       (1 << 3)

// Warning flags	(No actions necessary)
#define REGEN_WARN_FLAG           (1 << 10)
#define DYNAMIC_CONTROL_WARN_FLAG (1 << 11)
#define FLASH_SAVE_LIMIT_FLAG     (1 << 12)
// Soft error flags (RTD keeps on, torque ref to inverter is set to 0)

#define BSE_ERROR_FLAG  (1 << 16) // FSAE Rules: EV.5.7 (2021)
#define APPS_ERROR_FLAG (1 << 17) // FSAE Rules: T.4.2 (2021)

// Hard error flags (RTD disable)
#define INVERTER_CAN_TRANSMIT_ERROR_FLAG (1 << 19)
#define SU_F_ERROR_FLAG                  (1 << 20)
#define INVERTER_BUS_OFF_ERROR_FLAG      (1 << 21)
#define LEFT_INVERTER_COMM_ERROR_FLAG    (1 << 22)
#define RIGHT_INVERTER_COMM_ERROR_FLAG   (1 << 23)

#define ALL_WARN_FLAG        (REGEN_WARN_FLAG | DYNAMIC_CONTROL_WARN_FLAG)
#define ALL_MINOR_ERROR_FLAG (APPS_ERROR_FLAG | BSE_ERROR_FLAG)
#define ALL_SEVERE_ERROR_FLAG                                                            \
    (LEFT_INVERTER_COMM_ERROR_FLAG | RIGHT_INVERTER_COMM_ERROR_FLAG                      \
     | INVERTER_CAN_TRANSMIT_ERROR_FLAG | SU_F_ERROR_FLAG | INVERTER_BUS_OFF_ERROR_FLAG)
#define ALL_ERRORS_FLAG (ALL_SEVERE_ERROR_FLAG | ALL_MINOR_ERROR_FLAG)

#define ALL_THROTTLE_ERROR_FLAG (APPS_ERROR_FLAG | BSE_ERROR_FLAG)

// FUNCOES

//sets bit on the position and puts the byte as an state
__attribute__((always_inline)) inline void set_bit(uint32_t* byte, uint8_t pos,
                                                   uint8_t state) {
    *byte ^= (-(!!((unsigned long)state)) ^ *byte) & (1UL << pos);
}

__attribute__((always_inline)) inline void set_bit8(uint8_t* byte, uint8_t pos,
                                                    uint8_t state) {
    *byte ^= (-(!!((unsigned long)state)) ^ *byte) & (1UL << pos);
}

#endif /* INC_GLOBAL_DEFINITIONS_H_ */
